




let calcStatus = 0;  //0-empty  1-calcProcess 2-sendData
let calcTimeDuration = -100;//time for the end of timeout (paused(if error ))
let calcTimeOut =-1;

 function  getNewTask() {

    let answerStr = sendPostServer3("/command/getnewtask", "{}");
    //alert(answerStr);
    let answerObj = JSON.parse(answerStr);

    if (answerObj.errorStr!="none") {
                                    calcTimeOut = tNow+1;// 1 second for timeout
                                    calcStatus = 0;
                                    return;
                                    }



    if (answerObj.errorStr == "none") {
        //alert(answerObj.data);
        let curentFrame = answerObj.data.frame;
        let curentLine = answerObj.data.line;
        initScene(curentFrame,curentLine)//init parameters
        startXe = 0;//начинаем с левого пикселя
        calcStatus = 1;//признак что успешно загружена задача
        timeCalcStart = millis();//запоминаем когда начали

        }//if not error




}//getNewTask



function sendResultat(){

        if (calcStatus!=2) return;

        let resultatUrl = "/command/resultat/"+displayOpt.currentFrame+"/"+displayOpt.currentLine;
        //alert(calcResult.length);
        let answerStr = sendPostServerArray(resultatUrl,lineResultat);

      //  let answerObj = JSON.parse(answerStr);

        //if (answerObj.errorStr=="none") {
         //               timeAllDuration = answerObj.duration;
          //              }

        calcStatus = 0;
        }//sendResultat

