

let displayOpt= {

    "width": 320,
    "height": 240,
    "antia": 2,
    "fps": 25,


    "posX": 0.3,
    "posY": 0.1,
    "scaleX":0.003,
    "currentFrame":0,
    "currentLine":0,

    }//displayOpt


//parameters of camera
let sceneCam = new Camera();

let lineResultat = new  Uint8Array(100*3);

//time of calculation
let timeCalcStart = 0;//момент начала расчета
let timeCalcDuration  =  0;//продолжительность расчета
let timeAllDuration  =  0;//время расчета и транзакции

	
//this method return ray by screenCoord	
function rayByCam(xe,ye){

   	let rayRes = new Ray();
	rayRes.pos = sceneCam.pos;
	rayRes.dir = sceneCam.dir.vectorN(sceneCam.fov);
	
	let xr = +1.0*(xe-displayOpt.width*0.5) /displayOpt.width;
	let yr = -1.0*(ye-displayOpt.height*0.5)/displayOpt.height;

	//rayRes.dir.vectorAdd()
	rayRes.dir.vectorAdd(sceneCam.hor.vectorN(xr));
	rayRes.dir.vectorAdd( sceneCam.up.vectorN(yr));

	rayRes.dir.normalize();	
	return rayRes;
    }//rayByCam	



//Предрасчет параметров сцены
function initScene(frameNum,lineNum){


    displayOpt.currentFrame = frameNum;
    displayOpt.currentLine = lineNum;

        let t = frameNum*1.0/displayOpt.fps;

        //function for properties of teh scene
        displayOpt.scaleX = Math.exp(-t*1.0);

        displayOpt.posX = 0.39;
        displayOpt.posY = 0.3130205501;

		let angle = t*0.1;
		
		sceneCam.pos.x = 25.0*Math.cos(angle);
		sceneCam.pos.y = 25.0*Math.sin(angle);
		sceneCam.pos.z = 2.0;
		
		sceneCam.dir = sceneCam.pos.vectorN(-1.0);
		
		sceneCam.dir.x = 0.0 - sceneCam.pos.x;
		sceneCam.dir.y = 0.0 - sceneCam.pos.y;
		sceneCam.dir.z = 0.0 - sceneCam.pos.z;
		
		
		
	    //sceneCam.dir.set(1.0, 0, 0.01);
		sceneCam.dir.normalize();
		sceneCam.calcByDir();


        startXe = 0;


         //опционально пересоздаем массив линейки для результатов(нужного размера)
         if (displayOpt.width!=lineResultat.length){
                    lineResultat = new  Uint8Array(displayOpt.width*3);
                    }


         }//InitScene



