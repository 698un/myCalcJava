




let speed = 1;


 
 /**method calculate pixelColor
    deep - is deep of recursion(reflection count) 
 */
function rayToPixel(deep,ray){
	
	deep--;
	if (deep<=0) return new PixelRGB(0,0,0);

	//search object Intersect
	let pointIntersect = getIntersectByRay(ray);

	//defined material
	let matIntersect = matDefined(pointIntersect);

	let pixColor = matIntersect.color;
	
	
	//if reflection exist
	if (matIntersect.reflectionEnabled) {
		
		//create reflected ray
		let reflectRay = new Ray();
		
		
		reflectRay.pos = pointIntersect.pos;
		reflectRay.dir = ray.dir.vectMirror(matIntersect.normal);

		reflectRay.dir.normalize();
		
		//defined reflected point
		let reflectPixel =rayToPixel(deep,reflectRay);
		
		//blended mat color and reflection color
		pixColor.mixColor(reflectPixel,matIntersect.reflection);
		
   	    }//calculate reflection pixel
	
	
	return pixColor;
	
    }//rayToPixel


/**
 * This method calculate color one pixel on the screen
 * @param xe
 * @param ye
 * @returns PixelRGB
 */
 
function calcPixel(xe,ye){
  
	//
    let myRay = rayByCam(xe,ye);
	
	
	//first argument - deep of the recursion
	//second argument is ray 
	let resultPixel = rayToPixel(5,myRay);
  
    
    return resultPixel;
    }

   // let linePixel1 =  Array(5);
    //let iLine=0;
    let startXe=0;//стартовая точка следующего цикла


function nextCalcIteration() {

    //linePixel1[iLine] = new Uint8Array(displayOpt.width*3);
    //let linePixel = new Uint8Array(displayOpt.width*3);
    let antia = displayOpt.antia;


    let frameNum = displayOpt.currentFrame;
    let ye= displayOpt.currentLine;

    //alert("antia:"+displayOpt.antia+"width"+displayOpt.width+"height"+displayOpt.height);

    let rSum=0;
    let gSum=0;
    let bSum=0;

    let fxe =0.1;// XE с поправкой на антиальясинг
    let fye =0.1;
    let pxl;

    //defined range of calculate line
    let xeBegin = startXe;
    let xeEnd = startXe+speed;
    if (xeEnd>displayOpt.width) xeEnd =displayOpt.width;


    for (let xe=xeBegin; xe<xeEnd;xe++){

       // alert("xe:"+xe);

        rSum=0;
        gSum=0;
        bSum=0;

        //for antialiasing
        for (let ax=0;ax<antia;ax++){
            for (let ay=0;ay<antia;ay++) {

                fxe = xe + map(ax,0,antia,0,1);
                fye = ye + map(ay,0,antia,0,1);

                pxl = calcPixel(fxe, fye);

                rSum += pxl.r;
                gSum += pxl.g;
                bSum += pxl.b;
            }}//next ax,ay

        rSum = Math.round(rSum*1.0/antia/antia);
        gSum = Math.round(gSum*1.0/antia/antia);
        bSum = Math.round(bSum*1.0/antia/antia);

       // alert("rgb"+rSum+"/"+bSum+"/"+gSum);
        /*
        linePixel[xe*3+0]=rSum;//-127;
        linePixel[xe*3+1]=gSum;//-127;
        linePixel[xe*3+2]=bSum;//-127;
        */

        lineResultat[xe*3+0]=rSum;
        lineResultat[xe*3+1]=gSum;
        lineResultat[xe*3+2]=bSum;
        }//next xe

    startXe = xeEnd;
    if (xeEnd>= displayOpt.width) {
                        timeCalcDuration = millis()-timeCalcStart;
                        calcStatus = 2;//mark that calculation is complette
                        }

    }//next CalcIteration