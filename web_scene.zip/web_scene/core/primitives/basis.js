
//==========================RAY
class Ray{
    constructor() {
        this.pos = new Vector3(0,0,0);//position
        this.dir = new Vector3(1,0,0);//direction
        }//constructor
    }//class ray


//======================class point of intersect
class PointIntersect{
    constructor(){
        this.pos =     new Vector3(0,0,0);//position of intersect
        this.normal  = new Vector3(1.0,0,0);//direction normal in the point of intersect
		//this.distance = 1000000.0;
		
		this.index1 = 0; //index of intersesct Object
		this.index2 = 0; //second index of intersesct Object(if object is array)
		}//constructor
    }//class PontIntersect


//======================class PixelColor
class PixelRGB{
	constructor(inpR,inpG,inpB){
		this.r = inpR;
		this.g = inpG;
		this.b = inpB;
		}//constructor
		
	//shade width second color by triplet C(PixelRGB) 	
	mixColor(secondColor,c){
		this.r = this.r*(1.0-c.r) + secondColor.r*c.r;
		this.g = this.g*(1.0-c.g) + secondColor.g*c.g;
		this.b = this.b*(1.0-c.b) + secondColor.b*c.b;
		}//mixColor
	
	set(inpR,inpG,inpB){
		this.r=inpR;
		this.g=inpG;
		this.b=inpB;
		}//set
	
	}//class PixelRGB
	
class Camera{
	constructor(){
		this.dir = new Vector3(0,0,0);
		this.pos = new Vector3(0,0,0);
		this.up  = new Vector3(0,0,0);
		this.hor = new Vector3(0,0,0);
		this.fov = 0.5;
		}//constructor
		
	calcByDir(){
		
		this.up.set(0,0,+1.0);
		this.dir.normalize();
		this.hor = this.dir.vectProduct(this.up);
		this.up =  this.hor.vectProduct(this.dir);
		
		this.up.normalize();
		this.hor.normalize();
		}//calcByDir
		
	}//class Camera
		 
/**
Class is properties of material any object of the scene
*/			
class CMaterial{
	
	constructor(){
		//color of the material(in point of intersect)
		this.color =      new PixelRGB(0,0,0);
		//vector of the normal
		this.normal =     new Vector3(0,0,1);
		//reflection value by Red Green and Blue 
		this.reflection = new PixelRGB(0,0,0);
		//reflection enabled
		this.reflectionEnabled=false;
		
		}//constructor


	}//CMaterial		
