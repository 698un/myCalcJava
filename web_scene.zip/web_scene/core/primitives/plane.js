

//=======================PLANE=====================
class Plane{
    constructor(){
        this.pos = new Vector3();
        this.normal = new Vector3();
        }//constructor

    /**
     * This method calculate point of intersect Ray width this Plane
     * @param inpRay
     *  return Vector3 that is point of intersect
     *  return null if no intersect point
     */
    rayIntersect(ray){

        // if ray and plane.Normal ^^
        if (this.normal.sclrProduct(ray.dir)>=0) return null;

		//defined vector from ray to plane.center
        let PC = ray.pos.vectorTo(this.pos);

        //distance from plane to ray
        let distRayPosToPlanePos = PC.getModul();

        PC.modulValue = distRayPosToPlanePos;

        //PC.modul
        //scalar producrt PC and plane.N
        let scMlt = this.normal.sclrProduct(PC);

     //   let cosa =
	 }//rayIntersect
	 
}//class plane
