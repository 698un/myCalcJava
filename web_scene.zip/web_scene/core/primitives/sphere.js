

//=======================PLANE=====================
class Sphere{
    constructor(){
        this.pos = new Vector3(0,0,0);
        this.radius=1.0;
		
        }//constructor

    /**
     * This method calculate point of intersect Ray width this Plane
     * @param inpRay
     *  return Vector3 that is point of intersect
     *  return null if no intersect point
     */
    rayIntersect(ray){

		//distance from point of begin the ray to canter of the sphere
        let PC = ray.pos.vectorTo(this.pos);
		//modul of the vector PC
		let mPC = PC.getModul(); 	
		
		//cos angle betwen ray.dir and PC
		let cosa=ray.dir.scalarProduct(PC)/mPC;
		
		if (cosa<=0) return null;
		
		//calculate sin from value of the cos
		let sina=Math.sqrt(1.0-cosa*cosa);
		
		//distance from ray to center of then sphere
		let mCK = mPC*sina;
		
		//not intersect if distance bigest of then radius
		if (mCK>this.radius) return null;
		
		//calculate mPK
		let mPK = mPC*cosa;
		
		//calculate point K 
		let K = ray.pos.vectorPlus(ray.dir.vectorN(mPK));
		
		//calculate modul of MK
		let mMK = Math.sqrt(this.radius*this.radius-mCK*mCK);
		
		//calculate modul of the PM
		let mPM = mPK-mMK;
		
		let m=ray.pos.vectorPlus(ray.dir.vectorN(mPM));
		
		//calculate normmal in point of inrersect
		let normM = new Vector3(0,0,0);
		
		normM.x = m.x - this.pos.x;
		normM.y = m.y - this.pos.y;
		normM.z = m.z - this.pos.z;
		
		normM.normalize();
		
		//object resultat
		let res = new PointIntersect();
		
		res.normal = normM;
		res.pos = m;
		
		return res;

        }//rayIntersect

}







