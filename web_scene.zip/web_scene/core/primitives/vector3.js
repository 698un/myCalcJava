
//======================VECTOR3
class Vector3{
    constructor(ix,iy,iz){
        this.x = ix;
        this.y = iy;
        this.z = iz;
        this.modulValue = this.getModul();
        }//constructor vector2

    set(ix,iy,iz){
        this.x = ix;
        this.y = iy;
        this.z = iz;
        }

    normalize(){
        let m = Math.sqrt(this.x**2+
                          this.y**2+
                          this.z**2);
        if (m==0) m=1.0;
        this.x = 1.0*this.x/m;
        this.y = 1.0*this.y/m;
        this.z = 1.0*this.z/m;
        }//normalize

    distance(v2){
        let s = Math.sqrt((this.x-v2.x)**2+
                          (this.y-v2.y)**2+
                          (this.z-v2.z)**2);
        return s;
        }//distance

    /**
     * This method return scalar prouduct with v2
     */
    scalarProduct(v2){
        return this.x*v2.x+
               this.y*v2.y+
               this.z*v2.z;

        }//sclrProduct

    /*
    Return length of this vector
     */
    getModul() {
        this.modulValue= Math.sqrt(
            this.x ** 2 +
            this.y ** 2 +
            this.z ** 2
               );

        return this.modulValue;

        }//getModul


    /**
     * Return defiference v2 and this vector
     * 
     */
    vectorTo(v2){
        let v3 = new Vector3(
				        v2.x-this.x,
						v2.y-this.y,
						v2.z-this.z
						);
        return v3;
        }//vectorTo

	//this method return sum of this vector and vector in argument
	vectorPlus(v2){
		let vRez = new Vector3(
						this.x + v2.x,
						this.y + v2.y,
						this.z + v2.z
						);
		
		return vRez;
		}//vectorPlus

	//This method return this vector multiplied by argument(scalar)
	vectorN(multiValue){
		
		let vRes = new Vector3(
						this.x * multiValue,
						this.y * multiValue,
						this.z * multiValue
						);
		
		return vRes;
		}//vectorN


	vectorAdd(v2){
		
		this.x+=v2.x;
		this.y+=v2.y;
		this.z+=v2.z;
		
		}//vectorAdd

	//*This method calculate vectorProduct of this vector and v2(argument)
	vectProduct(v2){
		
		let vRes = new Vector3(0,0,0);
		
		vRes.x = this.y*v2.z - this.z*v2.y;
		vRes.y = this.z*v2.x - this.x*v2.z;
		vRes.z = this.x*v2.y - this.y*v2.z;
		return vRes;	
		}//vectProduct

	/**Method calculate Mirror vector of norm
	*/
	vectMirror(norm){
		let vMirror=new Vector3(0,0,0);
		
		let cosa = this.scalarProduct(norm);
		
		vMirror.x = this.x-norm.x*cosa*2.0;
		vMirror.y = this.y-norm.y*cosa*2.0;
		vMirror.z = this.z-norm.z*cosa*2.0;
		
		return vMirror;
		}//vectMirror
		
		




    }//class Vector3
