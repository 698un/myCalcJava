
class CilinderZ{
	
	
	constructor(pos){
		this.pos=new Vector3();//z==0;
		this.radius = 1.0;

		}//constructor

	/**
	This method calculate point of intersect
	ray with this cilinder
	*/
	rayIntersect(ray){

		//create 2D vector
		let ray2 = new Ray();
		ray2.dir = ray.dir;
		ray2.pos = ray.pos;
		ray2.pos.z = 0;
		ray2.dir.z = 0;
		ray2.dir.normalize();



		//distance from point of begin the ray to canter of the sphere
		let PC = ray2.pos.vectorTo(this.pos);
		//modul of the vector PC
		let mPC = PC.getModul();

		//cos angle betwen ray.dir and PC
		let cosa=ray.dir.scalarProduct(PC)/mPC;

		if (cosa<=0) return null;

		//calculate sin from value of the cos
		let sina=Math.sqrt(1.0-cosa*cosa);

		//distance from ray to center of then sphere
		let mCK = mPC*sina;

		//not intersect if distance bigest of then radius
		if (mCK>this.radius) return null;

		//calculate mPK
		let mPK = mPC*cosa;

		//calculate point K
		let K = ray2.pos.vectorPlus(ray2.dir.vectorN(mPK));

		//calculate modul of MK
		let mMK = Math.sqrt(this.radius*this.radius-mCK*mCK);

		//calculate modul of the PM
		let mPM = mPK-mMK;

		let m=ray2.pos.vectorPlus(ray2.dir.vectorN(mPM));

		//calculate normmal in point of inrersect
		let normM = new Vector3(0,0,0);

		normM.x = m.x - this.pos.x;
		normM.y = m.y - this.pos.y;
		normM.z = 0

		normM.normalize();

		//object resultat
		let res = new PointIntersect();

		//поправка на высоту
		m.z = m.z+ray.pos.z+1.0*mPM/ray.dir.z;

		res.distance = ray.pos.distance(m);


		res.normal = normM;
		res.pos = m;//с поправкой на высоту

		//return null;

		return res;



	}//intersect
	
	
}//cilinderZ