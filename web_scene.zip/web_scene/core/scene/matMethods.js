

/**This method define parameters of material if pointIntersect
	Argument is PointIntersect`
*/
function  matDefined(pointIntersect){
	
	//if (pointIntersect==null) return null;
	
	//intersect with background
	if (pointIntersect.index1==0) return backImg.getMaterial(pointIntersect);
	
	//intersect with floor
	if (pointIntersect.index1==1) return   floor.getMaterial(pointIntersect);
	
	if (pointIntersect.index1==2) return columns.getMaterial(pointIntersect);
	
	return null;//Exception 
	
	}//matDefine
	
	
	