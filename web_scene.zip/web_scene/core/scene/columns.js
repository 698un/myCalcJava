
/**
класс колонн
*/
class CColumns{
	
	
	constructor(inpCount,
	            inpDistance,
	            inpRadius,
				inpHeight){
					
		this.distance = inpDistance;//радиальное расстояние от центра
		this.count=inpCount;
		this.column = new Array(this.count);
		this.height = inpHeight;
		
		let angle=0.0;
		
		for (let i=0;i<this.count;i++){
			
//			angle = map(i,0,this.count,
	//		            0,TWO_PI);
			angle = Math.PI*2.0*i/this.count;
			
			
			this.column[i] = new CilinderZ();
			this.column[i].pos = new Vector3(
					this.distance*Math.cos(angle),
					this.distance*Math.sin(angle),
					0);
					
			this.column[i].radius = inpRadius;					
			}//next column
			
		}//constructor	
		
	/**Method calculate pointIntersect 
	verify with every column
	*/	
	rayIntersect(ray){

		
		let resPoint = null;
		
		
		let curPoint = new PointIntersect();
		
		for (let i=0;i<this.count;i++){
			
			curPoint = this.column[i].rayIntersect(ray);
			
			if (curPoint==null) continue;
			if (curPoint.pos.z<0) continue;
			if (curPoint.pos.z>this.height) continue;
			
			curPoint.index1 = 2;
			curPoint.index2 = i;
			
			if (resPoint==null) {
				  resPoint=curPoint;
			      continue;
				  }
				 
				 
			if (curPoint.distance<resPoint.distance) resPoint = curPoint;
			
			}//next columns
		
		
		return resPoint;
	}//rayIntersect



	getMaterial(point){

		let matResult = new CMaterial();

		matResult.normal =point.normal;
		matResult.color.set(255,0,0);


		matResult.reflectionEnabled=true;
		matResult.reflection.set(0.15,0.15,0.15);

		return matResult;

		}//getMaterial


					
}//class CColumns