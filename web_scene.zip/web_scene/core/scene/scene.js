


//OBJECTS of the SCENE
let backImg = new CBackImage();//задник
let floor =   new CFloor();//floor	
let columns = new CColumns(12,3,0.25,10.0);//columns
	
	

