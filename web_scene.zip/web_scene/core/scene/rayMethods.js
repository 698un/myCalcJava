



/**
This method defind object that intersect the ray
return pointIntersect
*/
function getIntersectByRay(ray){
	
	
	
	//resultat of methos(Point intersect)
	let resPoint = backImg.rayIntersect(ray);
	
	//object iteration
	let currentPoint;// = new PointIntersect();
	
	
	//floor defined
	currentPoint = floor.rayIntersect(ray);
	if (currentPoint!=null){
     		if (currentPoint.distance<resPoint.distance) resPoint = currentPoint;
			}//	
	

	//columns defined
	currentPoint = columns.rayIntersect(ray);
	if (currentPoint!=null){
     		if (currentPoint.distance<resPoint.distance) resPoint = currentPoint;
			}//	
	

	
		
	return resPoint;
	
	}//findObjectByRay



