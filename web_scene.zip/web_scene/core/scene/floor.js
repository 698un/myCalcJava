


class CFloor{
	
	constructor(){
		this.pos =    new Vector3(0,0,0);
		this.normal = new Vector3(0,0,1.0);
		}//constructor
		
		
	//This method calculate point of Intersect
    //return PointIntersect(object) or null	
	rayIntersect(ray){
		
		//no intersect if ray.dir.z > 0
		if (ray.dir.z>=0) return null;
		
		//no intersect if ray.position under floor
		if (ray.pos.z<=0) return null;
		
    	//length of ray to intersect with floor
		let lightLength = -1.0*ray.dir.z/(ray.pos.z-this.pos.z);
	
		//Point intersect
		let m= new Vector3(0,0,0);
		
		m.x=ray.pos.x + ray.dir.x*lightLength;
		m.y=ray.pos.y + ray.dir.y*lightLength;
		m.z=0;
		
		let result = new PointIntersect();
		result.pos = m;
		result.normal.set(0,0,+1.0);
		result.distance = lightLength;
		result.index1=1;//index of floor
		
		return result;
		
		}//


	getMaterial(point){

		let matResult = new CMaterial();
		
		matResult.normal =point.normal;
		matResult.color.set(0,0,0);
		
		
		let rad = Math.sqrt(Math.pow(point.pos.x,2)+
		                    Math.pow(point.pos.y,2)
							);
		
		//rad=rad%2;
		
		//if (rad%2>1 ) matResult.color.set(255,255,255);
		
		
		matResult.color.r=(Math.sin(rad*100.0)+1.0)*127.0;
		matResult.color.g=(Math.sin(rad*100.0)+1.0)*127.0;
		matResult.color.b=(Math.sin(rad*100.0)+1.0)*127.0;
		
		if (matResult.color.r>127) matResult.color.set(255,255,255);
		 
		
		//
		matResult.reflectionEnabled=true;
		matResult.reflection.set(0.15,0.15,0.15);
		
		return matResult;



		}//getMaterial		
	
}//class CFloor



