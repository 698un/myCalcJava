


class CBackImage{
	
	constructor(){
		this.distance = 1000.0;
		}//constructor
	
	//method calculate pointIntersect
	//
	rayIntersect(ray){
		
		let result = new PointIntersect();
		
		result.pos =    ray.dir.vectorN(this.distance);
		result.normal = ray.dir.vectorN(-1.0);
		result.normal.normalize();
		
		result.distance = this.distance;
		result.index1=0;//index of backImage
		
		return result;
		}//rayIntersect
		
	/**
	Method define parameters material in point of intersect
	return object material
	*/	
	getMaterial(point){
		
		let matResult = new CMaterial();
		
		matResult.color.r = (Math.sin(point.normal.x*100.0)+1.0)*127.0;
		matResult.color.g = (Math.sin(point.normal.y*100.0)+1.0)*127.0;
		matResult.color.b = (Math.sin(point.normal.z*100.0)+1.0)*127.0;
		
		//if (point.pos.y<0) matResult.color.set(0,0,255);
        if (point.pos.z<0) matResult.color.set(255,255,0);
		
		//matResult.color = new PixelRGB(0,0,255);
		
		matResult.reflectionEnabled=false;
		
		
		matResult.normal = point.normal;
				
		return matResult;
		}//getMaterial	
		
		
		
	}//class CBackImage	