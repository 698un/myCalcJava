






function sendPostServerArray(urlStr,arr) {
    let xhr = new XMLHttpRequest;
    xhr.open("POST", urlStr, false);
    xhr.setRequestHeader('Content-type', 'text/place; charset=UTF-8');

    let strAll="";
    let str1="";

    //преобразование результата в строку
    for (let i=0;i<arr.length;i++) {
        str1=""+arr[i];
        while (str1.length<3) {str1="0"+str1;}
        strAll+=str1;
        }//next i

    //alert(strAll);

    try {
        xhr.send(strAll);//send sting of numbers
        calcStatus = 0;
        }catch(e){
                calcTimeOut = tNow+1;// 5 second for timeout
                console.log("error of send array of the bytes")
                }

    }

