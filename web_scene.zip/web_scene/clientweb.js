
//управление физическим временем
let dt=0.01;
let tOld =0;
let tNow=0;
//значение поворота колеса мышы
let MW_delta = 0.01;
let MW_press = false;
let widthPrev = 0;
let heightPrev = 0;
//признак что пора пересчитать UI
let firstDraw=true;
let animatedEnabled = true;

let taskNumber=0;

let UI;

function setup() {
    createCanvas(800,500,P2D);

    //создание элементов управления
    UI = new UIClass();

    windowResized();
    animatedEnabled = false;
    }//setup

let screenFps = 10;

function draw() {

    //SYSTEM_FUNCTION
    if (firstDraw == true) {
        UI.rePosition();
        firstDraw = false;
        background(0);
        }


    //определение физического времени
    tNow = millis()*0.001;
    dt=tNow-tOld;
    tOld = tNow;
    MW_delta = 0;//reset to sero mouseWheelValue after cicle of draw
    MW_press = false;
    if (width!=widthPrev || height!=heightPrev ) windowResized();

    //закраска фоном
    if (animatedEnabled) {
 //       fonUpdate();
      //  image(loginFon, 0, 0, width, height);
        } else   background(0);



    UI.show();//loginControlShow

    fill(255)
    text(speed,100,100);
    text(startXe,100,125);
    text(frameRate(),100,150);
    text(displayOpt.width,100,175);

   screenFps=screenFps*0.5+frameRate()*0.5;


    //выход если пока не получили настройки с серверСтатус
    if (UI.UIStatus.serverStatus=="none") return;


    displayOpt.width = UI.UIStatus.serverStatus.imgWidth;
    displayOpt.height = UI.UIStatus.serverStatus.imgHeight;
    displayOpt.antia = UI.UIStatus.serverStatus.imgAntia;
    displayOpt.fps = UI.UIStatus.serverStatus.fps;

    //alert(displayOpt.width+" / "+displayOpt.height+" / "+displayOpt.antia);

    //forward containt only calculated function

    if (tNow<calcTimeOut) return;// abort cicle if timeout



    //если свободен то спрашиваем новую задачу
    if (calcStatus==0) {

                    try {
                        getNewTask();
                        } catch(e){
                                   calcStatus = 0;
                                   }

                    }

    //если процесс расчетов идет

    if (calcStatus==1) {
                    nextCalcIteration();


                    let fps = frameRate();
                    //поправка на SPEED
                    if (fps<20) speed--;
                    if (fps<15) speed=speed-10;
                    if (fps<10) speed=1;
                    if (fps>20) speed++;
                    //if (fps>30) speed=speed+10;

                    if (speed<1) speed = 1;
                    }

    if (calcStatus==2){
                    sendResultat();
                    }







}//draw



//function of leave from calculation
function cmdUnJoinClick(){
    let s1 =  sendPostServer3("/command/client/leave","{}");

    //alert(s1);
    let respJSON = JSON.parse(s1);//весь ответ как json объект

    //extract error message from response
    let errorStr = respJSON.errorStr;

    //if error then Message error end exit from function
    if (errorStr!="none") {
        alert(errorStr);
        return;
    }

    //    alert("exit");

    //If not error then run this function
    if (errorStr=="none") {
        alert("exit");
        //myUser = respJSON.data;
        document.location.href = '/index.html';
    }

}//cmdUnJoinClick












function windowResized() {

    resizeCanvas(windowWidth,windowHeight);
    widthPrev = windowWidth;
    heightPrev = windowHeight;
    UI.rePosition();
    createFon();

    //if (layerName = "menu") menuUI.rePosition();
    //if (layerName = "game") gameUI.rePosition();
    }//windowResized

function mouseWheel(event){
    MW_delta = event.deltaY;
    }

function mousePressed(event){
    MW_press = true;
}

