

/*
This Class contain all command for the work of the User
 */


package by.itstep.mySite.control.net.command;

//import by.itstep.mySite.dao.repository.UserRepository;
import by.itstep.mySite.service.AcceptException;
import by.itstep.mySite.control.net.NetRequest;

public class CmdUser {

    static UserService myService;

    /**
     * This method resease login in database
     * @param netReq  object of netRequest
     * @return  JSON object which contain errorMessage and user
     */
    public static StringBuffer getResultatLogin(NetRequest netReq) throws AcceptException{

        //get Service object
        myService = UserService.getService();

        System.out.println("========================="+netReq.getDataStr());

        String[] listStr = netReq.getDataStr().split(";");
        String loginStr = listStr[0];//
        String passwordStr = listStr[1];

        //Result of request
        StringBuffer rez = new StringBuffer("");

        try {
            User iUser = myService.enterUserByPassword(loginStr, passwordStr);
            rez.append(iUser.toJSON());
            netReq.setWebUser(iUser);
            } catch (Exception e) { throw new AcceptException(e.getMessage());   };

        System.out.println("resultat="+rez);

        return rez;

        }//getLogin


    /**
     * This methor return resultat of registration by Login and password
     * @param netReq
     * @return  JSON object an contain errorMessage and new user in dataBase
     */
    public static StringBuffer getResultatRegistration(NetRequest netReq){

        //get Service object
        myService = UserService.getService();

        //parse dataStr to field of User entity
        String[] listStr = netReq.getDataStr().split(";");
        String loginStr = listStr[0];//
        String passwordStr = listStr[1];

        //Result of request
        StringBuffer rez = new StringBuffer("");

        try {
            User iUser = myService.registration(loginStr, passwordStr);

            rez.append("{\"errorStr\":\"none\",");
            rez.append("\"user\":"+iUser.toJSON()+"}");

            } catch (Exception e) {
                rez.append("{\"errorStr\":\""+e.getMessage()+"\",");
                //hier write json object to errorMessage
                rez.append("\"user\":"+User.getGuestUser().toJSON()+"}");
                };

        System.out.println("resultat="+rez);

        return rez;

    }//getResultatRegistration


    /**
     * This method return resultat of exit (verifid by hash)
     * @param netReq
     * @return  JSON object an contain errorMessage
     */
    public static StringBuffer getResultatExit(NetRequest netReq) throws AcceptException{

        //get Service object
        myService = UserService.getService();

        String[] listStr = netReq.getDataStr().split(";");
        String loginStr = listStr[0];//
        String passwordStr = listStr[1];

        //Result of request
        StringBuffer rez = new StringBuffer("");

        try {
            //call method userExit(for reset hashSession)
            myService.userExit(netReq.getWebUser().getId());

            netReq.setWebUser(UserRepository.getRepository().getUserGuest());
            rez.append(netReq.getWebUser().toJSON());

        } catch (Exception e) { throw new AcceptException(e.getMessage());   };

        //System.out.println("resultat="+rez);

        return rez;

    }//getExit







/*
    public static StringBuffer getNewHashSession(){

        StringBuffer newHash = new StringBuffer();
        char c;
        for (int i=0;i<20;i++) {

            if (Math.random()<0.5) {
                c = (char) Math.round('a' + ('z' - 'a') * Math.random());
                } else c=(char)Math.round('A'+('Z'-'A')*Math.random());


            newHash.append(c);


        }//Next i

        return newHash;
        }//getNewHashSession
*/

}
