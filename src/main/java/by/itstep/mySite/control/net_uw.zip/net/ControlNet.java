package by.itstep.mySite.control.net;

import by.itstep.mySite.control.net.command.CommandCore;

import com.mysql.cj.util.StringUtils;

//import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.net.Socket;
//import java.nio.ByteBuffer;
//import java.nio.charset.Charset;
//import java.nio.charset.StandardCharsets;


//import by.itstep.mySite.control.net.CommandCore;

    public class ControlNet extends Thread{

    Socket socket;

    //constructor
    public ControlNet(Socket inpSocket){
        this.socket = inpSocket;
        setDaemon(true);
        start();
        }//Constructor



    public void run(){

        try {
            InputStream input = socket.getInputStream();//поток на входе серверу
            OutputStream output = socket.getOutputStream();//поток на выходе сервера(ответ)

            //объек запроса для удобства работы
            NetRequest netRequest = new NetRequest(input);//преобразование в объект запроса
            //if request not defined then EXIT
            if (netRequest.requestDataType==NRDataType.Unknow) {
                                                       socket.close();
                                                       return;
                                                       }


            System.out.println("+++++++++++++++++ Full request:");
            System.out.println(netRequest.content);

            //SECURITY FILTER
            netRequest.securityVerify();//call the security filter

            //System.out.println(netRequest.content);
            System.out.println(netRequest.firstLine);

            //Если запрашивается файл
            if (netRequest.requestDataType==NRDataType.WebFile) {
                  sendWebFile(netRequest,output);//отправляем файл в ответ
                  }//if this is webFile

            //если запрашиваються данные
            if (netRequest.requestDataType==NRDataType.WebData) {
                sendWebData(netRequest,output);//отправляем данные в ответ
                }//if this is webData

            output.flush();
            output.close();
            socket.close();

        }//try

        catch(Exception e) {
            e.printStackTrace();
            }//catch


    }//run



    //метод отправляет файл коиенту в ответ на запрос
    private void sendWebData(NetRequest nreq,OutputStream output){

        boolean error = false;//we assume that there are not error
        StringBuffer response;//head and data of response
        StringBuffer answerData;//Data of result
        int len=0;//length of responceData

        try {
            answerData = CommandCore.getResultat(nreq);
            } catch (Exception e) {

                    error=true;//set check that error exist
                    response = new StringBuffer("HTTP/1.1 404 +"+e.getMessage()+"\n");
                    try {
                        output.write(response.toString().getBytes());
                        output.flush();
                        output.close();
                        } catch (IOException e1) { System.out.println("IOE");}
                    return;
                    }


        //write in Head message "Not Error"
        response = new StringBuffer("HTTP/1.1 200 OK\n");

        //Calculate size of the Data of answer
        byte[] responseDataBytes = answerData.toString().getBytes();
        len = responseDataBytes.length;

        response.append("Last-Modified: " + new java.util.Date() + "\n");
        response.append("Content-Length: " + len + "\n");

        response.append("Content-Type: " + "text/plane; charset=utf-8" + "\n");
        //charset=windows-1251

        response.append("Connection: close\n");

        //hier send cookie that containt hashSession of webUser
        if ("/command/login".equals(nreq.getCommandStr())) {
                StringBuffer webUserStr=userJsonToUserStr(nreq.getWebUser());
                System.out.println(webUserStr);
                response.append("Web-user:"+webUserStr+ "\n");
                //response.append("Set-Cookie:web_user=23423423\n");
                //response.append("webuser:web_user=23423423\n");
                }

        //В конце заголовков обязательно должно быть две пустые строки,
        // иначе ответ не будет корректны образом обработан клиентом.
        response.append("Server: Server\n\n");

        //отправляем результат в ответ
        response.append( answerData );

        System.out.println("отправляем результат");
        System.out.println(response.toString());
        System.out.println("^^^^^^^^^^^^^^^^^");

        //производим запись параметров ответа
        try {

            output.write(response.toString().getBytes());


            output.flush();
            output.close();
            } catch (IOException e) { System.out.println("IOE");}

        }//sendWebData


    //метод отправляет файл коиенту в ответ на запрос
    private void sendWebFile(NetRequest nreq,OutputStream output){

        StringBuffer response = new StringBuffer("HTTP/1.1 200 OK\n");

        System.out.println("отправляем файл "+nreq.webFile.getAbsoluteFile());

        response.append("Last-Modified: " + new java.util.Date(nreq.webFile.lastModified()) + "\n");
        response.append("Content-Length: " + nreq.webFile.length() + "\n");
        response.append("Content-Type: " + nreq.mimeType + "\n");
        response.append("Connection: close\n");

        //В конце заголовков обязательно должно быть две пустые строки,
        // иначе ответ не будет корректны образом обработан клиентом.

         response.append("Server: Server\n\n");

         //производим запись параметров ответа
         try {
             output.write(response.toString().getBytes());
            } catch (IOException e) { System.out.println("IOE");}

         //Теперь отправляем файл
        try {
            FileInputStream fis = new FileInputStream(nreq.webFile.getAbsolutePath());

            byte[] buffer = new byte[256 * 1024];
            int write = 1;
            while (write > 0) {
                write = fis.read(buffer);
                if (write > 0) output.write(buffer, 0, write);
                }

            fis.close();

            } catch (IOException e) {System.out.println("IOE");}

    } //sendWebFile


    public static void main(String[] args){

        int portNumber = Integer.parseInt(args[0]);
        System.out.println(portNumber);

        try {
            ServerSocket server = new ServerSocket(portNumber);
            while (true){
                new ControlNet(server.accept());
                }//while
            }//try

        catch (Exception e) {
            System.out.println(e);
            }

    }//main





    private StringBuffer userJsonToUserStr(User inpUser){

            StringBuffer webUserStr = new StringBuffer("");
            webUserStr.setLength(0);

            //create string of webUser for save in the cookie
            webUserStr.append(Long.toString(inpUser.getId()));
            webUserStr.append("#");
            webUserStr.append(inpUser.getLogin());
            webUserStr.append("#");
            webUserStr.append(inpUser.getHashSession());

            return webUserStr;
            }



    //=================================================SECURITY   METHODS






}//class Server
