

/*
This Class contain all command for the work of the User

 */
package by.itstep.mySite.control.net.command;

import by.itstep.mySite.control.net.NetRequest;
import by.itstep.mySite.service.AcceptException;
import by.itstep.mySite.service.DocumentService;


import java.util.ArrayList;


public class CmdDocument {

    private static DocumentService myService;


    public static StringBuffer getResultatDocumentDepartment(NetRequest netReq) throws AcceptException{


        System.out.println("getResultatDocumentDepartment :"+netReq.commandStr);


        DocumentService docService = DocumentService.getService();

        //defined number of department
        int index_=-1;
        for (int i=0;i<netReq.commandStr.length();i++){
            if (netReq.commandStr.charAt(i)=='/') index_ = i;
            }
//        System.out.println("index_:"+index_);
        if (index_==-1) throw new AcceptException("Not correct request");
        long depId =  Long.parseLong(netReq.commandStr.substring(index_+1,netReq.commandStr.length()));
//        System.out.println("departmentID = "+depId);

        //get documentList by daprtment_ID
        try {
                ArrayList<Document> docList = docService.getDocumentInDepartment(depId);
                //return new StringBuffer("{dfd}");
                return getJSONdocList(docList);

                }   catch (Exception e) {
                    if (e.getClass()==AcceptException.class) throw new AcceptException(e.getMessage());
                    throw new AcceptException("Error DepartmenList Reload!!!");
                    }//catch

        }//getResultatDocumentDepartment






        private static StringBuffer getJSONdocList(ArrayList<Document> docList ){

            StringBuffer sbResult=new StringBuffer("");

            sbResult.append("[");

            for (int i=0;i<docList.size();i++){
                if (i!=0) sbResult.append(",");
                sbResult.append(docList.get(i).toJSONshort());
                }//next i
            sbResult.append("]");

            return sbResult;
            }//getJSONDocList




}//class CmdDepartment
