
/*

This class parse json request,
send its to controller,
gets answer from control,

 and generate json response
 */

package by.itstep.mySite.control.net.command;


import by.itstep.mySite.service.AcceptException;
import by.itstep.mySite.control.net.NetRequest;

//connect to utilits for control


public class CommandCore {


    //this method parse jsoncommand to object command
    //and execute this command

    public static StringBuffer getResultat(NetRequest netReq) throws AcceptException {


        try {

            if ("/command/login".equals(netReq.commandStr)) return CmdUser.getResultatLogin(netReq);
            if ("/command/registration".equals(netReq.commandStr)) return CmdUser.getResultatRegistration(netReq);
            if ("/command/exit".equals(netReq.commandStr)) return CmdUser.getResultatExit(netReq);


            if ("/command/departmentlist/hash".equals(netReq.commandStr)) return CmdDepartment.getResultatListHash(netReq);
            if ("/command/departmentlist/data".equals(netReq.commandStr)) return CmdDepartment.getResultatListData(netReq);

                                          // /command/document/dep/
            if (netReq.commandStr.indexOf("/command/document/dep/")>-1) return CmdDocument.getResultatDocumentDepartment(netReq);

            /*
            if ("/command/document/dep/hash".equals(netReq.commandStr)) return CmdDocument.getResultatDocData(netReq);
            if ("/command/documentlist/data".equals(netReq.commandStr)) return CmdDepartment.getResultatListData(netReq);
            */

            } catch (Exception e) {throw new AcceptException(e.getMessage()); }

        //System.out.println(netReq.commandStr);

        //Return Error if unknow command
        throw new AcceptException ("Unknow command");

        }//getResultat;




    //This method extract json user object
    private static StringBuffer getJsonUser(StringBuffer jsonStr){

        StringBuffer rez = new StringBuffer();
        int index = jsonStr.indexOf("}");
        for (int i=1;i<=index;i++){
            rez.append(jsonStr.charAt(i));
            }//next i

        return rez;
        }//getJsonUser

    //This method extract json command object
    private static StringBuffer getJsonCommand(StringBuffer jsonStr){

        StringBuffer rez = new StringBuffer();
        int index = jsonStr.indexOf("cmdName");
        for (int i=index-2;i<jsonStr.length()-1;i++){
            rez.append(jsonStr.charAt(i));
            }//next i

        return rez;
    }//getJsonUser






}//class CommandCore
