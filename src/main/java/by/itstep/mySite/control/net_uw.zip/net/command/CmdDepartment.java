

/*
This Class contain all command for the work of the User

 */
package by.itstep.mySite.control.net.command;


import by.itstep.mySite.control.net.NetRequest;

import by.itstep.mySite.service.AcceptException;
import by.itstep.mySite.service.DepartmentService;

import java.util.ArrayList;
import by.itstep.mySite.utilits.MyUtil;


public class CmdDepartment {

    static DepartmentService myService;

    //sorted,formated data
    static StringBuffer departmentListJSON = new StringBuffer("");//Last sendind JSON object

    //oldValue of hash
    static StringBuffer lastHash = new StringBuffer("01234567890");//Last sendind JSON object


    /**
     * This method resease login in database
     * @param netReq  object of netRequest
     * @return  JSON object which contain errorMessage and user
     */
    public static StringBuffer getResultatListHash(NetRequest netReq) {

        //TODO
        //defined right of webUser to gif updateHash
        //and return ERROR if right is not valid
        DepartmentService depService = DepartmentService.getService();
        //возвращаем updateHash списка разделов c DepartmentService
        StringBuffer currentHash =depService.getUpdateHash();
        return currentHash;
        }//getResultatHashList




    public static StringBuffer getResultatListData(NetRequest netReq) throws AcceptException{

        DepartmentService depService = DepartmentService.getService();
        //получаем возвращаем updateHash списка разделов c DepartmentService

         StringBuffer currentHash =depService.getUpdateHash();

         if (MyUtil.equalsSB2(lastHash,currentHash)==false) {
                                        lastHash = currentHash;

                                       try {
                                           reLoadDepartmentList();

                                           }   catch (Exception e) {
                                                   if (e.getClass()==AcceptException.class) throw new AcceptException(e.getMessage());
                                                   throw new AcceptException("Error DepartmenList Reload!!!");
                                                    }//catch


                                    }//if data id update


            //возвращаем кэшированный
            return departmentListJSON;
            //return new StringBuffer("{\'id\':9,\'Title\':\'КОРЕНЬ\'},{\'id\':10,\'Title\':\'Коммуникации\'}");
            //return new StringBuffer("{\'id\':9,\'Title\':\'square\'},{\'id\':10,\'Title\':\'Communication\'}");
        }//getResultatHashList




    //Рекурсивный метод добавления
    private static void addChilds(ArrayList<Department> depList,
                                 ArrayList<Department> depListSort,
                                 Department  parentObject){
        Department depChild;
        Department depParent;

        for (int i=0;i<depList.size();i++){
            depChild = depList.get(i);
            depParent = depChild.getParent();

            if (depParent==null) continue;//next entity if parent is not exists

            if (depChild.getParent().getId()==parentObject.getId()) {
                depChild.setLevel(parentObject.getLevel()+1);
                depListSort.add(depChild);
                addChilds(depList,depListSort,depChild);
                }//if this is child of parent

        }//next i

    }//addChilds


    private static void reLoadDepartmentList() throws AcceptException{

        ArrayList<Department> depList;
        ArrayList<Department> depListSort = new ArrayList<Department>();

        //get list of department from service
        myService = DepartmentService.getService();



        try {
             depList =myService.getDepartmentList();

             }   catch (Exception e) { throw new AcceptException(e.getMessage()); }


        depListSort.clear();
        //set Level
        //Boolean tmpb=true;

        long dummyId = myService.getDepartmenByTitle("dummy").getId();
        int dummyIndex = -1;
        System.out.println("*************************************dummyId ="+dummyId);

        //search index of dummy
        for (int i = 0;i<depList.size();i++) {
            depList.get(i).setLevel(-1);
            if (depList.get(i).getId() == dummyId)  {
                                                depList.get(i).setLevel(0);
                                                dummyIndex = i;
                                                }
            }//next i




        //добавляем всех потомков начаная с dummy
        addChilds(depList, depListSort, depList.get(dummyIndex));

        System.out.println("*************************************Count ="+depList.size());

        depList = depListSort;

        //representation List in JSON object
        StringBuffer jsonArray = new StringBuffer("");

        //jsonArray.append("{\"errorStr\":\"none\",\"data\":");

        jsonArray.append("[");
        for (int i=0;i<depList.size();i++){
        //for (int i=0;i<2;i++){
            if (i!=0) jsonArray.append(","); //separator betwen object of array
            jsonArray.append(depList.get(i).toJSON());
            }//next i

        jsonArray.append("]");
        departmentListJSON = jsonArray;

        }//reLoad




}//class CmdDepartment
