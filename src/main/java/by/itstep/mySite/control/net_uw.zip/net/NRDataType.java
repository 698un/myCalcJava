package by.itstep.mySite.control.net;

public enum NRDataType {
    WebFile,WebData,Unknow;
}
