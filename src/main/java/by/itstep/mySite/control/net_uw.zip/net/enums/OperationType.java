
package by.itstep.mySite.control.net.enums;
/**
 * Variants of Request
 */
public enum OperationType {
    UNKNOW,
    POST_CLIENT_KEY,
    GET_WEB_FILE,
    GET_STATUS,
    POST_RESULTAT;
    }//NRDataType
