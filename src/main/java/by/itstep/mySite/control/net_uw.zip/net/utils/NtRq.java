
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

//import net.bytebuddy.asm.Advice;


/**
 * This class is entyity of Reguest
 from user
 */
public class NtRq {
	//Full content of the reguest
	StringBuffer content;
  
	//type of http reguest
	private HttpType httpType;
	public HttpType getHttpType() { return this.httpType; }

	//FirstLine in the request
	private String firstLine;

	//URL string(withouth type request)
	private String urlStr;
	public String getUrl() {return this.urlStr;}

	private String streamStr;//Head and body of request

	StringBuffer fileExt;
	StringBuffer mimeType;
	public File webFile;
	public OperationType operationType;//тип запроса( webfile , webdata,....
	String dataStr;//data in user command
	
	static StringBuffer sbNoFile = new StringBuffer("nofile.html");

	public String getDataStr() {
		return this.dataStr;
		}//data in user request
	

  //Constructor
  public NtRq( InputStream input) throws IOException {

    //Default the operation is not defined      
    this.operationType = OperationType.UNKNOW;
	
	//array of bytes that containt if reguest
    byte[] buffer = new byte[256*1024];//массив ба��т в к��торый запишем запрос клиента
    int bytesCount = input.read(buffer);//читаем массив байтов на входе
  
    //Exit if size reguest is zero
    if (bytesCount<=0) return;
    //convert full stream in String
    String streamStr = new String(buffer, 0, bytesCount);//преобразуем в одну строку весь поток данных

	//Parse
    this.parseRequest();
    
    //definedClientKey
    this.definedClientKey(streamStr);
	
	//if (this.
        
  // this.content = new StringBuffer(str1);

  //    this.defineRequestType();//defined request type (get,post,  .....)
  //  this.firstLine = getFirstLine(content);//defined URL in request

    //System.out.println("Firstline:" + this.firstLine);

    //this.searchFileName();        //defined request to file
    //this.searchCommand();         //defined request to data from DataBase
    //this.searchWebUser();         //defined sender in request

   // if (this.requestDataType == NRDataType.WebFile) System.out.println("ЭТО ФАЙЛ НА СЕРВЕРЕ");
   // if (this.requestDataType == NRDataType.WebData) System.out.println("ЭТО КО��АНДА СЕРВЕРУ");

    //System.out.println("Firstline:"+this.firstLine);
    //if (this.isWebFile) System.out.println("ЭТО ФАЙЛ НА СЕРВЕРЕ");
    //if (!this.isWebFile) System.out.println("ЭТО НЕ ФАЙЛ НА СЕРВЕРЕ!!!");
  }//constructor


	private void parseRequest(){
		this.definedFirstLine();
		}//


	//defined firstLine of the request
	private void definedFirstLine(){
		int indexInString = streamStr.indexOf("\n");
		if (indexInString==-1) return;
		this.firstLine = streamStr.substring(0,indexInString);
	
		//only if FirstLine defined
		this.definedHttpType();
		}//definedFirstLine

    
	private void definedHttpType(){
		this.httpType = HttpType.UNKNOW;
		if (firstLine.indexOf("GET ")==0) this.httpType = HttpType.GET;
		if (firstLine.indexOf("POST ")==0) this.httpType = HttpType.POST;
	
		//exit if not defined    
		if (this.httpType == HttpType.UNKNOW) return;    
		defineURL();
		}
	
	
    private void defineURL(){
  
		int index1 =  this.firstLine.indexOf(" ");
		if (index1==-1) return;
		int index2 = -1;
		for (int i=this.firstLine.length();i>=0;i--){
			if (this.firstLine.charAt(i)==' ') {
				index2=i;
				break;
				}//IF find the backspace 	 
			}//next i
			
		if (index2<=index1) return;
		this.urlStr = this.firstLine.substring(index1,index2);
		
		this.defineOperationType();
		
		}//defined URl
		
	private void defineOperationType(){
		this.operationType=OperationType.UNKNOW;
		
		//GET_Mapping
		if (this.httpType==HttpType.GET) {
			
			//Mapping("/WebFile")
			if (this.isWebFile()) this.operationType=OperationType.GET_WEB_FILE;
			//Mapping("/status")
			if ("/status".equals(this.urlStr)) this.operationType=OperationType.GET_STATUS;

			}//HTTP_GET
			
   	    //POST_Mapping(регистрация в системе)
		if (this.httpType==HttpType.POST) {
			
			//Mapping("/clienttask")//получение ClientKey
			if ("
			
			}//HTTP_POST
			
		
	
		}//defineOperation




	private boolean isWebFile(){
	
		String webFolder  = Opt.getOptions.get("webfolder");

		if (this.httpType==HttpType.POST) return false;
		
		this.fileName = new StringBuffer("nofile.html");
		
		fileName.setLength(0);//очищаем fileName

		//поправка на "?"
		boolean param = false;
		for (int i=5; i<indexLast; i++) {
			if (firstLine.charAt(i)=='?') param = true;
			//if not arguments then add every symbol
			if (param==false)fileName.append(firstLine.charAt(i));
			}//next i

    //String fname = firstLine.substring(5,indexLast);
    //fileName = new StringBuffer(fname);
    //System.out.println("filename="+fileName);


    //if file is exist
    this.webFile = WebFiles.getFileObject(this);

    if (this.webFile!=null) {
      this.requestDataType = NRDataType.WebFile;
      defineFileExt();
      return;
      }

    //если все же файл не существует
    this.fileName = sbNoFile;

    this.requestDataType = NRDataType.WebFile;//marks request that WEBFILE
  }//getFileName



  /**
   * This method search in head of request an webUser object
   */
  private void defineClientKey(String inpString) {
    int index = inpString.indexOf("ClientKey: ");
    if (index==-1) return;// exit if WebUser in header not found
    //define last symbol in ClientKey
    int indexLast = inpString.indexOf("\n", index);
    this.clientKey = inpString.substring(index+9, indexLast);
    System.out.println("ClientKey:"+this.ClientKey);
    }//definedClientKey



  public void searchCommand() {

    //commandStr = new StringBuffer();

    //defined signature of command in head of request
    if (firstLine.indexOf("POST /command")!=0) return;//исключаем команды
    int indexLast = firstLine.indexOf(" HTTP/");
    if (indexLast==-1) return;

    //extract  command from url
    this.commandStr = this.firstLine.substring(5, indexLast);

    //search begin index of sending data
    //"SEND_DATA:" - sign of begin data
    int dataIndex =-1;
    dataIndex = this.content.indexOf("SEND_DATA:");//+10;

    if (dataIndex>0) {
      dataIndex+=10;
      this.dataStr = this.content.substring(dataIndex, content.length());
    } else dataStr = null;

    this.requestDataType = NRDataType.WebData;//set typeRequest to WebData
    //System.out.println("++++++++++++++++++++++++++++++++++++commandStr="+this.commandStr);
    //System.out.println("+++++++++++++++++++++++++++++++++++++++dataStr="+this.dataStr);
  }//searchCommand





  public void setFile(File f1) {
    this.webFile = f1;
  }

  private void defineFileExt() {
    int dotIndex = -1;//индекс точки

    //search dotIndex
    for (int i=0; i<this.fileName.length(); i++) {
      if (this.fileName.charAt(i)=='.') dotIndex = i;
    }//next i

    if (dotIndex==-1) {
      this.fileExt = new StringBuffer("---");
      return;
    }//if dot not found

    //create Extention of file
    this.fileExt = new StringBuffer();
    for (int i=dotIndex+1; i<this.fileName.length(); i++) fileExt.append(this.fileName.charAt(i));


    //определяем mimeType для ответа
    if (StringBuffer_equals(this.fileExt, "jpg")) this.mimeType = new StringBuffer("image/jpeg");
    if (StringBuffer_equals(this.fileExt, "js"))  this.mimeType = new StringBuffer("text/javascript");
    if (StringBuffer_equals(this.fileExt, "html"))this.mimeType = new StringBuffer("text/html");
    if (StringBuffer_equals(this.fileExt, "gif")) this.mimeType = new StringBuffer("image/gif");
    if (StringBuffer_equals(this.fileExt, "ico")) this.mimeType = new StringBuffer("image/vnd.microsoft.icon");

    //System.out.println(this.fileExt);
    //System.out.println(this.mimeType);
  }//defineFileExt



  /**
   * Метод выделяет имя файла из заголовка
   * @param lineStr
   * @return
   */
  private void searchFileName() {

    this.fileName = new StringBuffer("nofile.html");

    if (firstLine.indexOf("GET /command/")==0) return;//исключаем команды

    if (firstLine.indexOf("GET /")!=0) return;
    int indexLast = firstLine.indexOf(" HTTP/");
    if (indexLast==-1) return;

    fileName.setLength(0);//очищаем fileName

    //поправка на "?"
    boolean param = false;
    for (int i=5; i<indexLast; i++) {
      if (firstLine.charAt(i)=='?') param = true;
      //if not arguments then add every symbol
      if (param==false)fileName.append(firstLine.charAt(i));
    }//next i

    //String fname = firstLine.substring(5,indexLast);
    //fileName = new StringBuffer(fname);
    //System.out.println("filename="+fileName);


    //if file is exist
    this.webFile = WebFiles.getFileObject(this);

    if (this.webFile!=null) {
      this.requestDataType = NRDataType.WebFile;
      defineFileExt();
      return;
    }

    //если все же файл не существует
    this.fileName = sbNoFile;

    this.requestDataType = NRDataType.WebFile;//marks request that WEBFILE
  }//getFileName

  private StringBuffer getFirstLine(StringBuffer sb1) {

    int firstLineEnd = sb1.indexOf("\n");
    //формируем заголовок из запроса
    StringBuffer rez = new StringBuffer();

    //заносим посимвольно пока не встретим enter
    for (int i=0; i<sb1.length(); i++) {
      if (sb1.charAt(i)==13) break;
      rez.append(sb1.charAt(i));
    }//next i

    return rez;
  }//getFirstLine


  public Boolean StringBuffer_equals(StringBuffer sb1, String str1) {

    int len1 = sb1.length();
    if (len1!=str1.length()) return false;
    if (len1==0) return true;

    for (int i=0; i<len1; i++) {
      if (sb1.charAt(i)!=str1.charAt(i)) return false;
    }//next i

    return true;
  }//stringBuffer_equals


  //=====================================s e c u r i t y    m e t h o d s========================================

  public void securityVerify() {

    this.definedRealUser2();

    // Call method that verify access to  files
    if (this.requestDataType==NRDataType.WebFile) this.securityVerifyFiles();

    //Call method that verify access to the data
    if (this.requestDataType==NRDataType.WebData) this.securityVerifyData();
  }



  /**
   * This Method getting entity of user that reguest the  data
   */
  private void definedRealUser2() {

    this.webUser = new User();
    User guestDB = UserRepository.getRepository().getUserGuest();

    this.webUser.setRole(guestDB.getRole());
    this.webUser.setLogin(guestDB.getLogin());



    try {
      // webuser=5#698UN#RWRrmYfrHNEmnqrfIhpi
      int index = this.content.indexOf("webuser=");
      index+=8;//translate by length of "webuser="

      int indexLast = -1;
      int indexLast1 = this.content.indexOf("\n", index);
      int indexLast2 = this.content.indexOf(";", index);

      //если оба найдены
      if (indexLast1 > index && indexLast2 > index) indexLast = Math.min(indexLast1, indexLast2);

      //��сл�� один из них не найден
      if (indexLast1 * indexLast2 <= 0) indexLast = Math.max(indexLast1, indexLast2);

      //defined key of Sender
      StringBuffer webUserStr = new StringBuffer("");
      for (int i = index; i < indexLast; i++) webUserStr.append(this.content.charAt(i));
      //System.out.println("!!!!!!!!!!!!!!!!!!WEBUSER_STR="+webUserStr);

      //defined positions of the separators
      int first_ = webUserStr.indexOf("#");
      int second_ = webUserStr.indexOf("#", first_ + 1);

      Long webUserId = Long.parseLong(webUserStr.substring(0, first_));

      //abort search if not user in database
      User userInDB = UserRepository.getRepository().getUserById(webUserId);


      //defined role this webUser
      this.webUser.setRole(userInDB.getRole());

      //verify HashSession
      String webHashSession = webUserStr.substring(second_ + 1, webUserStr.length() - 1);
      //abort if not equals hashSession
      if (webHashSession.equals(userInDB.getHashSession()) == false) {
        throw new Exception("df");
      }

      this.webUser.setId(Long.parseLong(webUserStr.substring(0, first_)));
      this.webUser.setLogin(webUserStr.substring(first_ + 1, second_));
      this.webUser.setHashSession(webUserStr.substring(second_ + 1, webUserStr.length() - 1));

      //Verify hashSession and set webUser to guest if acces not denied
      if (this.webUser.getHashSession().equals(UserRepository.getRepository().getUserByLogin(webUser.getLogin()).getHashSession()) == false)
        this.webUser = User.getGuestUser();

      //by any exception set webUser guest
    } 
    catch (Exception e) {
      this.webUser = UserRepository.getRepository().getUserGuest();
    }




    //this.webUser = UserRepository.getRepository().getUserByLogin(webUser.getLogin());
    System.out.println(this.webUser.toString());
  }//definedRealUser

















  private void securityVerifyFiles() {

    //abort method if user regue access for not work directory
    if (this.firstLine.indexOf("work")==-1) return;

    //get to nullFile if guest
    if ("guest".equals(this.webUser.getRole().getTitle())) {
      this.setFile(getNullFile());
    }//if access denied
  }// securityVerifyFiles







  private void securityVerifyData() {
    //no filter if calling login
    if ("/command/login".equals(this.commandStr)) return;
  }//securityVerifyData(){


  private static File nullFile;
  private File getNullFile() {

    if (nullFile==null) {
      nullFile = new File(App.appPath +
        File.separator +
        "web" +
        File.separator +
        "access_denied.html"
        );
    }   //if nullFile not create



    return nullFile;
  }
  

	//Type of http request
	public enum HttpType {
		GET, POST, DELETE, UNKNOW;
		}

	//Type of operations
	public enum OperationType {
		UNKNOW,
		POST_CLIENT_KEY,
		GET_WEB_FILE,
		GET_STATUS,		
		POST_RESULTAT;
		}//NRDataType
  
  
}//class NetRequest
