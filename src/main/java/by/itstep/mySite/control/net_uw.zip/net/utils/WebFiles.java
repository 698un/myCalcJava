
package by.itstep.mySite.control.net;
/**
 * Control for WebFiles
 */

import java.io.File;


public class WebFiles {

    private static String webPath="none";
    //private File file1;

    public static java.io.File getFileObject(NetRequest nRequest){

        //if  (nRequest.fileName)



        File myFile = new File(getWebPath()+nRequest.fileName);

        System.out.println("Проверяем наличие файла: "+
                           myFile.getAbsoluteFile()
                           );

        if (myFile.exists()) {
            System.out.println("такой есть!!!");
            return myFile;
            }
        System.out.println("такого нет!!!");
        return null;
    }//webFileIsExist



    public static String getWebPath(){
        if ("none".equals(webPath)) {
                        webPath = System.getProperty("user.dir")+
                                  File.separator+
                                  "web"+
                                  File.separator;
                        }
        return webPath;

    }//getWebPath


}//class WebFiles
