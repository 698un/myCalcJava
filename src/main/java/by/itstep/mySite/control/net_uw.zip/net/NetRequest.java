/*
Этот класс описывает сущность и методы
запроса от клиента
 */


package by.itstep.mySite.control.net;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import by.itstep.mySite.App;
import by.itstep.mySite.dao.repository.UserRepository;
//import net.bytebuddy.asm.Advice;


/**
 * Created by 698UN on 11.09.2021.
 */
public class NetRequest {


    StringBuffer content;//полный запрос

    public StringBuffer firstLine;//заголовок запроса


    HttpType httpType;//тип запроса (Get,Put,Delete,Post.....)


    public String commandStr;// command key
    //public StringBuffer jsonStr;//json representation of command

    public StringBuffer fileName;//ссылка на файл если он есть в запросе
    StringBuffer fileExt;//расширенме запрашиваемого файла
    StringBuffer mimeType;
    public File webFile;
    public NRDataType requestDataType;//тип запроса( webfile , webdata,....
    String dataStr;//data in user command
    User webUser;//sender of command


    public void setHttpType(HttpType inpType){
           this.httpType = inpType;
           }



    static StringBuffer sbNoFile = new StringBuffer("nofile.html");

    public String getCommandStr(){
        return this.commandStr;
        }//getCommandStr

    public String getDataStr(){return this.dataStr;}//data in user request
    public User getWebUser(){return this.webUser;}//data in user request
    public void setWebUser(User inpUser){this.webUser = inpUser;}//data in user request
    //constructor
    //public NetRequest(String str1) {



    public NetRequest( InputStream input) throws IOException {

        this.httpType =      HttpType.UNKNOW;//предполагаем что запрос неопознан
        this.operationType = OperationType.UNKNOW;//предполагаем что запрос неопознан


        byte[] buffer = new byte[256*1024];//массив байт в который запишем запрос клиента
        int bytesCount = input.read(buffer);//читаем массив байтов на входе
        if (bytesCount<=0) return;

        String streamStr = new String(buffer,0,bytesCount);//преобразуем в одну строку весь поток данных

        //parse this request by inputStream
        NTParse.parse(this,streamStr);

       //this.content = readContentFromRequest(input);

        NRParse.parse()
        this.firstLine = NRParse(str1);

        //преобразуем в StringBuffer
        this.content = new StringBuffer(str1);

        this.defineRequestType();//defined request type (get,post,  .....)
        this.firstLine = getFirstLine(content);//defined URL in request

        System.out.println("Firstline:" + this.firstLine);

        this.searchFileName();        //defined request to file
        this.searchCommand();         //defined request to data from DataBase
        //this.searchWebUser();         //defined sender in request


        if (this.requestDataType == NRDataType.WebFile) System.out.println("ЭТО ФАЙЛ НА СЕРВЕРЕ");
        if (this.requestDataType == NRDataType.WebData) System.out.println("ЭТО КОМАНДА СЕРВЕРУ");

        //System.out.println("Firstline:"+this.firstLine);
        //if (this.isWebFile) System.out.println("ЭТО ФАЙЛ НА СЕРВЕРЕ");
        //if (!this.isWebFile) System.out.println("ЭТО НЕ ФАЙЛ НА СЕРВЕРЕ!!!");

        }//constructor





    /**
     * This method search in head of request an webUser object
     */
    private void searchWebUser(){

        //default sender is guest
        this.webUser=User.getGuestUser();

        //define start symbol in WebUser
        int index = this.content.indexOf("WebUser: ");
        if (index==-1) return;// exit if WebUser in header not found
        //define last symbol in WebUser
        int indexLast = this.content.indexOf("\n",index);

        String webUserStr = this.content.substring(index+9,indexLast);
        System.out.println("++++++++++++++++++++++++WEBUSER:"+webUserStr);

        String[] webUserField = webUserStr.split(";");
        webUser.setId(Long.parseLong(webUserField[0]));
        webUser.setLogin(webUserField[1]);
        webUser.setHashSession(webUserField[0]);

        Role webUserRole= UserRepository.getRepository().getUserByLogin(webUser.getLogin()).getRole();
        webUser.setRole(webUserRole);

        }//searchWebUser



    public void searchCommand(){

        //commandStr = new StringBuffer();

        //defined signature of command in head of request
        if (firstLine.indexOf("POST /command")!=0) return;//исключаем команды
        int indexLast = firstLine.indexOf(" HTTP/");
        if (indexLast==-1) return;

        //extract  command from url
        this.commandStr = this.firstLine.substring(5,indexLast);

        //search begin index of sending data
        //"SEND_DATA:" - sign of begin data
        int dataIndex =-1;
        dataIndex = this.content.indexOf("SEND_DATA:");//+10;

        if (dataIndex>0) {
                        dataIndex+=10;
                        this.dataStr = this.content.substring(dataIndex,content.length());
                        } else dataStr = null;

       this.requestDataType = NRDataType.WebData;//set typeRequest to WebData
       //System.out.println("++++++++++++++++++++++++++++++++++++commandStr="+this.commandStr);
       //System.out.println("+++++++++++++++++++++++++++++++++++++++dataStr="+this.dataStr);


       }//searchCommand





    public void setFile(File f1){
        this.webFile = f1;
        }

    private void defineFileExt(){
        int dotIndex = -1;//индекс точки

        //search dotIndex
        for (int i=0;i<this.fileName.length();i++){
            if (this.fileName.charAt(i)=='.') dotIndex = i;
            }//next i

        if (dotIndex==-1) {
            this.fileExt = new StringBuffer("---");
            return;
            }//if dot not found

        //create Extention of file
        this.fileExt = new StringBuffer();
        for (int i=dotIndex+1;i<this.fileName.length();i++) fileExt.append(this.fileName.charAt(i));


        //определяем mimeType для ответа
        if (StringBuffer_equals(this.fileExt,"jpg")) this.mimeType = new StringBuffer("image/jpeg");
        if (StringBuffer_equals(this.fileExt,"js"))  this.mimeType = new StringBuffer("text/javascript");
        if (StringBuffer_equals(this.fileExt,"html"))this.mimeType = new StringBuffer("text/html");
        if (StringBuffer_equals(this.fileExt,"gif")) this.mimeType = new StringBuffer("image/gif");
        if (StringBuffer_equals(this.fileExt,"ico")) this.mimeType = new StringBuffer("image/vnd.microsoft.icon");

        //System.out.println(this.fileExt);
        //System.out.println(this.mimeType);

        }//defineFileExt

    private void defineRequestType(){
        //определяем тип запроса
        this.reqType = RequestType.Unknow;//по умолчанию неопознан
        if (content.indexOf("GET")==0) this.reqType=RequestType.Get;
        if (content.indexOf("DELETE")==0) this.reqType=RequestType.Delete;
        }//defineRequestType


    /**
     * Метод выделяет имя файла из заголовка
     * @param lineStr
     * @return
     */
    private void searchFileName(){

        this.fileName = new StringBuffer("nofile.html");

        if (firstLine.indexOf("GET /command/")==0) return;//исключаем команды

        if (firstLine.indexOf("GET /")!=0) return;
        int indexLast = firstLine.indexOf(" HTTP/");
        if (indexLast==-1) return;

        fileName.setLength(0);//очищаем fileName

        //поправка на "?"
        boolean param = false;
        for (int i=5;i<indexLast;i++){
            if (firstLine.charAt(i)=='?') param = true;
            //if not arguments then add every symbol
            if (param==false)fileName.append(firstLine.charAt(i));
            }//next i

        //String fname = firstLine.substring(5,indexLast);
        //fileName = new StringBuffer(fname);
        //System.out.println("filename="+fileName);


        //if file is exist
        this.webFile = WebFiles.getFileObject(this);

        if (this.webFile!=null) {
              this.requestDataType = NRDataType.WebFile;
              defineFileExt();
              return;
              }

        //если все же файл не существует
        this.fileName = sbNoFile;

        this.requestDataType = NRDataType.WebFile;//marks request that WEBFILE
        }//getFileName

    private StringBuffer getFirstLine(StringBuffer sb1){

        int firstLineEnd = sb1.indexOf("\n");
        //формируем заголовок из запроса
        StringBuffer rez = new StringBuffer();

        //заносим посимвольно пока не встретим enter
        for (int i=0;i<sb1.length();i++){
            if (sb1.charAt(i)==13) break;
            rez.append(sb1.charAt(i));
            }//next i

        return rez;

        }//getFirstLine


    public Boolean StringBuffer_equals(StringBuffer sb1,String str1){

            int len1 = sb1.length();
            if (len1!=str1.length()) return false;
            if (len1==0) return true;

            for (int i=0;i<len1;i++){
                if (sb1.charAt(i)!=str1.charAt(i)) return false;
                }//next i

            return true;

        }//stringBuffer_equals


    //=====================================s e c u r i t y    m e t h o d s========================================

    public void securityVerify(){

        this.definedRealUser2();

        // Call method that verify access to  files
        if (this.requestDataType==NRDataType.WebFile) this.securityVerifyFiles();

        //Call method that verify access to the data
        if (this.requestDataType==NRDataType.WebData) this.securityVerifyData();

        }



    /**
     * This Method getting entity of user that reguest the  data
     */
    private void definedRealUser2(){

        this.webUser = new User();
        User guestDB = UserRepository.getRepository().getUserGuest();

        this.webUser.setRole(guestDB.getRole());
        this.webUser.setLogin(guestDB.getLogin());



        try {
            // webuser=5#698UN#RWRrmYfrHNEmnqrfIhpi
            int index = this.content.indexOf("webuser=");
            index+=8;//translate by length of "webuser="

            int indexLast = -1;
            int indexLast1 = this.content.indexOf("\n", index);
            int indexLast2 = this.content.indexOf(";", index);

            //если оба найдены
            if (indexLast1 > index && indexLast2 > index) indexLast = Math.min(indexLast1, indexLast2);

            //если один из них не найден
            if (indexLast1 * indexLast2 <= 0) indexLast = Math.max(indexLast1, indexLast2);

            //defined key of Sender
            StringBuffer webUserStr = new StringBuffer("");
            for (int i = index; i < indexLast; i++) webUserStr.append(this.content.charAt(i));
            //System.out.println("!!!!!!!!!!!!!!!!!!WEBUSER_STR="+webUserStr);

            //defined positions of the separators
            int first_ = webUserStr.indexOf("#");
            int second_ = webUserStr.indexOf("#", first_ + 1);

            Long webUserId = Long.parseLong(webUserStr.substring(0, first_));

            //abort search if not user in database
            User userInDB = UserRepository.getRepository().getUserById(webUserId);


            //defined role this webUser
            this.webUser.setRole(userInDB.getRole());

            //verify HashSession
            String webHashSession = webUserStr.substring(second_ + 1, webUserStr.length() - 1);
            //abort if not equals hashSession
            if (webHashSession.equals(userInDB.getHashSession()) == false) {throw new Exception("df");}

            this.webUser.setId(Long.parseLong(webUserStr.substring(0, first_)));
            this.webUser.setLogin(webUserStr.substring(first_ + 1, second_));
            this.webUser.setHashSession(webUserStr.substring(second_ + 1, webUserStr.length() - 1));

            //Verify hashSession and set webUser to guest if acces not denied
            if (this.webUser.getHashSession().equals(UserRepository.getRepository().getUserByLogin(webUser.getLogin()).getHashSession()) == false)
                this.webUser = User.getGuestUser();

            //by any exception set webUser guest
            } catch (Exception e) {this.webUser = UserRepository.getRepository().getUserGuest();}




        //this.webUser = UserRepository.getRepository().getUserByLogin(webUser.getLogin());
        System.out.println(this.webUser.toString());


    }//definedRealUser

















    private void securityVerifyFiles(){

        //abort method if user regue access for not work directory
        if (this.firstLine.indexOf("work")==-1) return;

        //get to nullFile if guest
        if ("guest".equals(this.webUser.getRole().getTitle())) {
                        this.setFile(getNullFile());
                        }//if access denied

        }// securityVerifyFiles







    private void securityVerifyData(){
        //no filter if calling login
        if ("/command/login".equals(this.commandStr)) return;



        }//securityVerifyData(){


    private static File nullFile;
    private File getNullFile(){

        if (nullFile==null) {
            nullFile = new File(App.appPath +
                                    File.separator +
                                    "web" +
                                    File.separator +
                                   "access_denied.html"
                                    );
            }   //if nullFile not create



        return nullFile;
        }


    //Type of http request
    public enum HttpType {
        GET, POST, DELETE, UNKNOW;
        }

    //Type of operations
    public enum OperationType {
        UNKNOW,
        POST_CLIENT_KEY,
        GET_WEB_FILE,
        GET_STATUS,
        POST_RESULTAT;
        }//NRDataType



}//class NetRequest
