package by.itstep.mySite.control.net;

public class NTParse {

    public static void parse(NetRequest netReq,String streamStr) throws AcceptException{

        try {
            //defined first line (EXAMPLE "GET /index.html /HTTP 1.2")
            netReq.setFirstLine(definedFirstLine(streamStr));

            //define HTTP type (get,post , ...)
            netReq.setHttpType(definedHttpType(netReq.getFirstLine());


        } catch (Exception e) {
                throw new AcceptException("Bad format of request");
                }

        }//parse

    //defined firstLine of the request
    private String definedFirstLine(String streamStr) throws AcceptException{
        try {
            int indexInString = streamStr.indexOf("\n");
            String firstLine = streamStr.substring(0, indexInString);
            }  catch (Exception e) throw new AcceptException("bad format of request");

            }//definedFirstLine

    private HttpType getHttpType(String firstLine){

        HttpType result = HttpType.UNKNOW;

        if (firstLine.indexOf("GET")==0)    return HttpType.GET;
        if (firstLine.indexOf("POST")==0)   return HttpType.POST;
        if (firstLine.indexOf("DELETE")==0) return HttpType.DELETET;

        return HttpType.UNKNOW;


        }//getHttpType

}
