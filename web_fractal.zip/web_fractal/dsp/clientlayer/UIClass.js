






//========UI
class UIClass {
    constructor() {
        //датчик сервера
        this.UIStatus = new ServerStatus();


        //кнопка подключения
        this.cmdUnJoin = createButton('leave from Calculation');
        this.cmdUnJoin.position(0, 0);
        this.cmdUnJoin.mousePressed(cmdUnJoinClick);

        //название произошедшего события
        this.eventName ="none";

        }//constuctor

    rePosition(){

        this.cmdUnJoin.position(width/2-this.cmdUnJoin.width/2,height/2-this.cmdUnJoin.height/2);


    }//rePosition


    show(){
        this.UIStatus.show();

        }//controlShow

    eventListen(){
        this.eventName = "none";
        if (mouseIsPressed==false) return this.eventName;

        if (this.cmdLogin.eventMouseDown()==true)        this.eventName = "command_login";
        if (this.cmdRegistration.eventMouseDown()==true) this.eventName = "command_registration";

        return this.eventName;
        }//eventListen


    }//class menuUIClass

