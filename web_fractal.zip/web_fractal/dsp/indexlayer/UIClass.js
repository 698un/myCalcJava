






//========UI
class UIClass {
    constructor() {

        //датчик сервера
        this.UIStatus = new ServerStatus();


        //кнопка подключения
        this.cmdJoin = createButton('Join to calculations');
        this.cmdJoin.position(0, 0);
        this.cmdJoin.mousePressed(cmdJoinClick);

        //название произошедшего события
        this.eventName ="none";

        }//constuctor





    rePosition(){

        this.cmdJoin.position(width/2-this.cmdJoin.width/2,height/2-this.cmdJoin.height/2);


        }//rePosition


    show(){
        this.cmdJoin.show();
        this.UIStatus.show();

        }//controlShow

    eventListen(){

        if (this.eventName=="cmdJoinClick") {
                        return "command_join";
                        this.eventName ="none";
                        }



        this.eventName = "none";
        if (mouseIsPressed==false) return this.eventName;

        return this.eventName;
        }//eventListen


    }//class menuUIClass

