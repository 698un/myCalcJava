



let firstDraw=true;

let UI;

function dspSetup(){
        UI = new UIClass();

        }//loginSetup


function dspDraw(){

    if (firstDraw==true) {
        UI.rePosition();
        firstDraw=false;
        }

    //закраска фоном
    if (animatedEnabled) {
        fonUpdate();
        image(loginFon, 0, 0, width, height);
        }

    if (animatedEnabled==false) {
        background(0,0,255);
        }


     UI.show();//loginControlShow


     let controlEvent = UI.eventListen(); //прослушивание контроллера

}//loginDraw




function cmdJoinClick(){
        let s1 =  sendPostServer3("/command/getclientkey","{}");

        //alert(s1);
        let respJSON = JSON.parse(s1);//весь ответ как json объект

        //extract error message from response
        let errorStr = respJSON.errorStr;

        //if error then Message error end exit from function
        if (errorStr!="none") {
            alert(errorStr);
            return;
            }

        //If not error then run this function
        if (errorStr=="none") {
            myUser = respJSON.data;
            document.location.href = '/clientindex.html';
            }

    }//cmdJoinClick




