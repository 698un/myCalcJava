
let speed = 1;

function ff(cx, cy) {

    var x = 0.0;
    var y = 0.0;
    var xx = 0;
    var yy = 0;
    var xy = 0;
    var i = deep;
    while (i-- && xx + yy <= 4) {
        xy = x * y;
        xx = x * x;
        yy = y * y;
        x = xx - yy + cx;
        y = xy + xy + cy;
    }
    return deep - i;
}


let  deep =5000;

/**
 * This methos calculate one pixel
 * @param xe
 * @param ye
 * @returns {ArrayBuffer}
 */
function calcPixel(xe,ye){
    //пиксел - триплей трех байт
    let result = new ArrayBuffer(3);

    let scaleY = displayOpt.scaleX*1.0*displayOpt.height/displayOpt.width;


    //переводим экранные коорждинаты в математические
    let rxe = map( xe,0,displayOpt.width,
              displayOpt.posX-displayOpt.scaleX, displayOpt.posX+displayOpt.scaleX);

    let rye = map( ye,0,displayOpt.height,
        displayOpt.posY-scaleY, displayOpt.posY+scaleY);


    let iterCount = ff(rxe,rye);

    let cr = (iterCount*1)%255;
    let cg = (iterCount*2)%255;
    let cb = (iterCount*3)%255;

    result[0]=cr;
    result[1]=cg;
    result[2]=cb;

    return result;
    }

   // let linePixel1 =  Array(5);
    //let iLine=0;
    let startXe=0;//стартовая точка следующего цикла


function nextCalcIteration() {

    //linePixel1[iLine] = new Uint8Array(displayOpt.width*3);
//    let linePixel = new Uint8Array(displayOpt.width*3);
    let antia = displayOpt.antia;


    let frameNum = displayOpt.currentFrame;
    let ye= displayOpt.currentLine;

    //alert("antia:"+displayOpt.antia+"width"+displayOpt.width+"height"+displayOpt.height);

    let rSum=0;
    let gSum=0;
    let bSum=0;

    let fxe =0.1;// XE с поправкой на антиальясинг
    let fye =0.1;
    let pxl;

    //defined range of calculate line
    let xeBegin = startXe;
    let xeEnd = startXe+speed;
    if (xeEnd>displayOpt.width) xeEnd =displayOpt.width;


    for (let xe=xeBegin; xe<xeEnd;xe++){

       // alert("xe:"+xe);

        rSum=0;
        gSum=0;
        bSum=0;

        //for antialiasing
        for (let ax=0;ax<antia;ax++){
            for (let ay=0;ay<antia;ay++) {

                fxe = xe + map(ax,0,antia,0,1);
                fye = ye + map(ay,0,antia,0,1);

                pxl = calcPixel(fxe, fye);

                rSum += pxl[0];
                gSum += pxl[1];
                bSum += pxl[2];
            }}//next ax,ay

        rSum = Math.round(rSum*1.0/antia/antia);
        gSum = Math.round(gSum*1.0/antia/antia);
        bSum = Math.round(bSum*1.0/antia/antia);

       // alert("rgb"+rSum+"/"+bSum+"/"+gSum);
        /*
        linePixel[xe*3+0]=rSum;//-127;
        linePixel[xe*3+1]=gSum;//-127;
        linePixel[xe*3+2]=bSum;//-127;
        */

        lineResultat[xe*3+0]=rSum;
        lineResultat[xe*3+1]=gSum;
        lineResultat[xe*3+2]=bSum;
        }//next xe

    startXe = xeEnd;
    if (xeEnd>= displayOpt.width) {
                        timeCalcDuration = millis()-timeCalcStart;
                        calcStatus = 2;//mark that calculation is complette
                        }

    }